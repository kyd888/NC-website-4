Publish dir: NC_website/frontend
Injected meta: yes
Removed .env files: 4
Converted images to webp: 8
Upload this zip to Netlify (Deploys → Upload a deploy).