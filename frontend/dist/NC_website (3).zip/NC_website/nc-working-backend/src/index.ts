import path from "path";
import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import { fileURLToPath } from "url";

import { adminRouter } from "./routes/admin.js";
import { accountRouter } from "./routes/account.js";
import { catalogRouter } from "./routes/catalog.js";
import { adminUiRouter } from "./routes/admin_ui.js";
import { seedInventory } from "./lib/inventory.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const PORT = Number(process.env.PORT || 8787);

const defaultOrigins = [
  `http://localhost:${PORT}`,
  `http://127.0.0.1:${PORT}`,
  "http://localhost:5173",
  "http://127.0.0.1:5173",
  process.env.FRONTEND_ORIGIN,
  process.env.BACKEND_ORIGIN,
].filter(Boolean) as string[];

const allowedOrigins = new Set(defaultOrigins);

app.use(
  cors({
    origin(origin, callback) {
      if (!origin) return callback(null, true);
      if (allowedOrigins.has(origin)) return callback(null, true);
      return callback(new Error("Origin not allowed by CORS"));
    },
    credentials: true,
  }),
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const staticRoot = path.resolve(__dirname, "../public");
app.use("/uploads", express.static(path.join(staticRoot, "uploads")));
app.use(express.static(staticRoot));

app.use("/api/admin", adminRouter);
app.use("/api/account", accountRouter);
app.use("/api", catalogRouter);
app.use("/admin", adminUiRouter);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

seedInventory();

app.listen(PORT, () => {
  console.log(`NC backend ready on http://localhost:${PORT}`);
  console.log(`Admin UI:       http://localhost:${PORT}/admin`);
});
